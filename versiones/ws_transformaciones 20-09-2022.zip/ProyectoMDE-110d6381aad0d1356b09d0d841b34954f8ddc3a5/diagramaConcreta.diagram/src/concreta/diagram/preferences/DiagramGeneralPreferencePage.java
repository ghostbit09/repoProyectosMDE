/*
 * 
 */
package concreta.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

import concreta.diagram.part.ConcretaDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	* @generated
	*/
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(ConcretaDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
