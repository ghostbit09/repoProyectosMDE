/*
 * 
 */
package concreta.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

import concreta.diagram.part.ConcretaDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	* @generated
	*/
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(ConcretaDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
