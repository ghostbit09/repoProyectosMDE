/*
 * 
 */
package concreta.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class ConcretaIconProvider extends DefaultElementTypeIconProvider implements IIconProvider {

	/**
	* @generated
	*/
	public ConcretaIconProvider() {
		super(ConcretaElementTypes.TYPED_INSTANCE);
	}

}
