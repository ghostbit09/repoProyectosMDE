/*
 * 
 */
package concreta.diagram.edit.helpers;

/**
 * @generated
 */
public class MBSAtributoEditHelper extends ConcretaBaseEditHelper {
}
