/*
 * 
 */
package concreta.diagram.providers.assistants;

import concreta.diagram.providers.ConcretaModelingAssistantProvider;

/**
 * @generated
 */
public class ConcretaModelingAssistantProviderOfMBSMetodoEditPart extends ConcretaModelingAssistantProvider {

}
