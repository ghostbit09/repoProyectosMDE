/*
 * 
 */
package concreta.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	* @generated
	*/
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Messages() {
	}

	/**
	* @generated
	*/
	public static String ConcretaCreationWizardTitle;

	/**
	* @generated
	*/
	public static String ConcretaCreationWizard_DiagramModelFilePageTitle;

	/**
	* @generated
	*/
	public static String ConcretaCreationWizard_DiagramModelFilePageDescription;

	/**
	* @generated
	*/
	public static String ConcretaCreationWizard_DomainModelFilePageTitle;

	/**
	* @generated
	*/
	public static String ConcretaCreationWizard_DomainModelFilePageDescription;

	/**
	* @generated
	*/
	public static String ConcretaCreationWizardOpenEditorError;

	/**
	* @generated
	*/
	public static String ConcretaCreationWizardCreationError;

	/**
	* @generated
	*/
	public static String ConcretaCreationWizardPageExtensionError;

	/**
	* @generated
	*/
	public static String ConcretaDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String ConcretaDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String ConcretaDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	* @generated
	*/
	public static String ConcretaDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	* @generated
	*/
	public static String ConcretaDocumentProvider_isModifiable;

	/**
	* @generated
	*/
	public static String ConcretaDocumentProvider_handleElementContentChanged;

	/**
	* @generated
	*/
	public static String ConcretaDocumentProvider_IncorrectInputError;

	/**
	* @generated
	*/
	public static String ConcretaDocumentProvider_NoDiagramInResourceError;

	/**
	* @generated
	*/
	public static String ConcretaDocumentProvider_DiagramLoadingError;

	/**
	* @generated
	*/
	public static String ConcretaDocumentProvider_UnsynchronizedFileSaveError;

	/**
	* @generated
	*/
	public static String ConcretaDocumentProvider_SaveDiagramTask;

	/**
	* @generated
	*/
	public static String ConcretaDocumentProvider_SaveNextResourceTask;

	/**
	* @generated
	*/
	public static String ConcretaDocumentProvider_SaveAsOperation;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String InitDiagramFile_WizardTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	* @generated
	*/
	public static String ConcretaNewDiagramFileWizard_CreationPageName;

	/**
	* @generated
	*/
	public static String ConcretaNewDiagramFileWizard_CreationPageTitle;

	/**
	* @generated
	*/
	public static String ConcretaNewDiagramFileWizard_CreationPageDescription;

	/**
	* @generated
	*/
	public static String ConcretaNewDiagramFileWizard_RootSelectionPageName;

	/**
	* @generated
	*/
	public static String ConcretaNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	* @generated
	*/
	public static String ConcretaNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	* @generated
	*/
	public static String ConcretaNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	* @generated
	*/
	public static String ConcretaNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	* @generated
	*/
	public static String ConcretaNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	* @generated
	*/
	public static String ConcretaNewDiagramFileWizard_InitDiagramCommand;

	/**
	* @generated
	*/
	public static String ConcretaNewDiagramFileWizard_IncorrectRootError;

	/**
	* @generated
	*/
	public static String ConcretaDiagramEditor_SavingDeletedFile;

	/**
	* @generated
	*/
	public static String ConcretaDiagramEditor_SaveAsErrorTitle;

	/**
	* @generated
	*/
	public static String ConcretaDiagramEditor_SaveAsErrorMessage;

	/**
	* @generated
	*/
	public static String ConcretaDiagramEditor_SaveErrorTitle;

	/**
	* @generated
	*/
	public static String ConcretaDiagramEditor_SaveErrorMessage;

	/**
	* @generated
	*/
	public static String ConcretaElementChooserDialog_SelectModelElementTitle;

	/**
	* @generated
	*/
	public static String ModelElementSelectionPageMessage;

	/**
	* @generated
	*/
	public static String ValidateActionMessage;

	/**
	* @generated
	*/
	public static String Objects1Group_title;

	/**
	* @generated
	*/
	public static String Connections2Group_title;

	/**
	* @generated
	*/
	public static String MBSAtributo1CreationTool_title;

	/**
	* @generated
	*/
	public static String MBSAtributo1CreationTool_desc;

	/**
	* @generated
	*/
	public static String MBSClase2CreationTool_title;

	/**
	* @generated
	*/
	public static String MBSClase2CreationTool_desc;

	/**
	* @generated
	*/
	public static String MBSMetodo3CreationTool_title;

	/**
	* @generated
	*/
	public static String MBSMetodo3CreationTool_desc;

	/**
	* @generated
	*/
	public static String MBSPaquete4CreationTool_title;

	/**
	* @generated
	*/
	public static String MBSPaquete4CreationTool_desc;

	/**
	* @generated
	*/
	public static String MBSContainment1CreationTool_title;

	/**
	* @generated
	*/
	public static String MBSContainment1CreationTool_desc;

	/**
	* @generated
	*/
	public static String MBSHerencia2CreationTool_title;

	/**
	* @generated
	*/
	public static String MBSHerencia2CreationTool_desc;

	/**
	* @generated
	*/
	public static String MBSRelacion3CreationTool_title;

	/**
	* @generated
	*/
	public static String MBSRelacion3CreationTool_desc;

	/**
	* @generated
	*/
	public static String MBSClaseMBSClaseAtributosCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String MBSClaseMBSClaseMetodosCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String CommandName_OpenDiagram;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSDiagramaClases_1000_links;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSClase_2001_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSClase_2001_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSRelacion_4001_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSRelacion_4001_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSHerencia_4002_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSHerencia_4002_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSContainment_4003_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSContainment_4003_source;

	/**
	* @generated
	*/
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	* @generated
	*/
	public static String MessageFormatParser_InvalidInputError;

	/**
	* @generated
	*/
	public static String ConcretaModelingAssistantProviderTitle;

	/**
	* @generated
	*/
	public static String ConcretaModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
