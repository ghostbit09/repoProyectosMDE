/*
* 
*/
package concreta.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class ConcretaNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	* @generated
	*/
	public ConcretaNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}
