/*
 * 
 */
package concreta.diagram.edit.helpers;

/**
 * @generated
 */
public class MBSContainmentEditHelper extends ConcretaBaseEditHelper {
}
