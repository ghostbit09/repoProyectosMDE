package diagrama.model;

public class TransformacionM2T {

}
