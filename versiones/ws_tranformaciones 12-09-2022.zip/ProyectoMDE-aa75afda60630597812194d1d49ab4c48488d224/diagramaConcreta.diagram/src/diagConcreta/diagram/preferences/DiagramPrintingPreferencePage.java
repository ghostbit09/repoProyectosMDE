/*
 * 
 */
package diagConcreta.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.PrintingPreferencePage;

/**
 * @generated
 */
public class DiagramPrintingPreferencePage extends PrintingPreferencePage {

	/**
	* @generated
	*/
	public DiagramPrintingPreferencePage() {
		setPreferenceStore(
				diagConcreta.diagram.part.DiagConcretaDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
