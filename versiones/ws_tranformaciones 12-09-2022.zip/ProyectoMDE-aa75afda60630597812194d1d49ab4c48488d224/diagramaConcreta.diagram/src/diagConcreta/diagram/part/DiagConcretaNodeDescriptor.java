/*
* 
*/
package diagConcreta.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class DiagConcretaNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	* @generated
	*/
	public DiagConcretaNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}
