/*
 * 
 */
package diagConcreta.diagram.part;

import org.eclipse.gmf.tooling.runtime.actions.DefaultDeleteElementAction;
import org.eclipse.ui.IWorkbenchPart;

/**
 * @generated
 */
public class DeleteElementAction extends DefaultDeleteElementAction {

	/**
	* @generated
	*/
	public DeleteElementAction(IWorkbenchPart part) {
		super(part);
	}

}
