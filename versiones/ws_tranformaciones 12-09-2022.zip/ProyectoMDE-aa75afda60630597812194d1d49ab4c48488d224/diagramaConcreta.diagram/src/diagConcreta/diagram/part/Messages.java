/*
 * 
 */
package diagConcreta.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	* @generated
	*/
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Messages() {
	}

	/**
	* @generated
	*/
	public static String DiagConcretaCreationWizardTitle;

	/**
	* @generated
	*/
	public static String DiagConcretaCreationWizard_DiagramModelFilePageTitle;

	/**
	* @generated
	*/
	public static String DiagConcretaCreationWizard_DiagramModelFilePageDescription;

	/**
	* @generated
	*/
	public static String DiagConcretaCreationWizard_DomainModelFilePageTitle;

	/**
	* @generated
	*/
	public static String DiagConcretaCreationWizard_DomainModelFilePageDescription;

	/**
	* @generated
	*/
	public static String DiagConcretaCreationWizardOpenEditorError;

	/**
	* @generated
	*/
	public static String DiagConcretaCreationWizardCreationError;

	/**
	* @generated
	*/
	public static String DiagConcretaCreationWizardPageExtensionError;

	/**
	* @generated
	*/
	public static String DiagConcretaDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String DiagConcretaDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String DiagConcretaDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	* @generated
	*/
	public static String DiagConcretaDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	* @generated
	*/
	public static String DiagConcretaDocumentProvider_isModifiable;

	/**
	* @generated
	*/
	public static String DiagConcretaDocumentProvider_handleElementContentChanged;

	/**
	* @generated
	*/
	public static String DiagConcretaDocumentProvider_IncorrectInputError;

	/**
	* @generated
	*/
	public static String DiagConcretaDocumentProvider_NoDiagramInResourceError;

	/**
	* @generated
	*/
	public static String DiagConcretaDocumentProvider_DiagramLoadingError;

	/**
	* @generated
	*/
	public static String DiagConcretaDocumentProvider_UnsynchronizedFileSaveError;

	/**
	* @generated
	*/
	public static String DiagConcretaDocumentProvider_SaveDiagramTask;

	/**
	* @generated
	*/
	public static String DiagConcretaDocumentProvider_SaveNextResourceTask;

	/**
	* @generated
	*/
	public static String DiagConcretaDocumentProvider_SaveAsOperation;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String InitDiagramFile_WizardTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	* @generated
	*/
	public static String DiagConcretaNewDiagramFileWizard_CreationPageName;

	/**
	* @generated
	*/
	public static String DiagConcretaNewDiagramFileWizard_CreationPageTitle;

	/**
	* @generated
	*/
	public static String DiagConcretaNewDiagramFileWizard_CreationPageDescription;

	/**
	* @generated
	*/
	public static String DiagConcretaNewDiagramFileWizard_RootSelectionPageName;

	/**
	* @generated
	*/
	public static String DiagConcretaNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	* @generated
	*/
	public static String DiagConcretaNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	* @generated
	*/
	public static String DiagConcretaNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	* @generated
	*/
	public static String DiagConcretaNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	* @generated
	*/
	public static String DiagConcretaNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	* @generated
	*/
	public static String DiagConcretaNewDiagramFileWizard_InitDiagramCommand;

	/**
	* @generated
	*/
	public static String DiagConcretaNewDiagramFileWizard_IncorrectRootError;

	/**
	* @generated
	*/
	public static String DiagConcretaDiagramEditor_SavingDeletedFile;

	/**
	* @generated
	*/
	public static String DiagConcretaDiagramEditor_SaveAsErrorTitle;

	/**
	* @generated
	*/
	public static String DiagConcretaDiagramEditor_SaveAsErrorMessage;

	/**
	* @generated
	*/
	public static String DiagConcretaDiagramEditor_SaveErrorTitle;

	/**
	* @generated
	*/
	public static String DiagConcretaDiagramEditor_SaveErrorMessage;

	/**
	* @generated
	*/
	public static String DiagConcretaElementChooserDialog_SelectModelElementTitle;

	/**
	* @generated
	*/
	public static String ModelElementSelectionPageMessage;

	/**
	* @generated
	*/
	public static String ValidateActionMessage;

	/**
	* @generated
	*/
	public static String Objects1Group_title;

	/**
	* @generated
	*/
	public static String Connections2Group_title;

	/**
	* @generated
	*/
	public static String MBSAtributo1CreationTool_title;

	/**
	* @generated
	*/
	public static String MBSAtributo1CreationTool_desc;

	/**
	* @generated
	*/
	public static String MBSClase2CreationTool_title;

	/**
	* @generated
	*/
	public static String MBSClase2CreationTool_desc;

	/**
	* @generated
	*/
	public static String MBSMetodo3CreationTool_title;

	/**
	* @generated
	*/
	public static String MBSMetodo3CreationTool_desc;

	/**
	* @generated
	*/
	public static String MBSPaquete4CreationTool_title;

	/**
	* @generated
	*/
	public static String MBSPaquete4CreationTool_desc;

	/**
	* @generated
	*/
	public static String MBSParametro5CreationTool_title;

	/**
	* @generated
	*/
	public static String MBSParametro5CreationTool_desc;

	/**
	* @generated
	*/
	public static String MBSRelacion1CreationTool_title;

	/**
	* @generated
	*/
	public static String MBSRelacion1CreationTool_desc;

	/**
	* @generated
	*/
	public static String MBSClaseMBSClaseAtributosCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String MBSClaseMBSClaseMetodosCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String CommandName_OpenDiagram;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSDiagramaClases_1000_links;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSClase_2001_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSClase_2001_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSRelacion_4001_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_MBSRelacion_4001_source;

	/**
	* @generated
	*/
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	* @generated
	*/
	public static String MessageFormatParser_InvalidInputError;

	/**
	* @generated
	*/
	public static String DiagConcretaModelingAssistantProviderTitle;

	/**
	* @generated
	*/
	public static String DiagConcretaModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
