/*
 * 
 */
package diagConcreta.diagram.providers.assistants;

/**
 * @generated
 */
public class DiagConcretaModelingAssistantProviderOfMBSMetodoEditPart
		extends diagConcreta.diagram.providers.DiagConcretaModelingAssistantProvider {

}
