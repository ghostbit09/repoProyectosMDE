/*
 * 
 */
package diagConcreta.diagram.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

/**
 * @generated
 */
public class DiagConcretaEditPartProvider extends DefaultEditPartProvider {

	/**
	* @generated
	*/
	public DiagConcretaEditPartProvider() {
		super(new diagConcreta.diagram.edit.parts.DiagConcretaEditPartFactory(),
				diagConcreta.diagram.part.DiagConcretaVisualIDRegistry.TYPED_INSTANCE,
				diagConcreta.diagram.edit.parts.MBSDiagramaClasesEditPart.MODEL_ID);
	}

}
