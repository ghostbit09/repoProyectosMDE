/*
 * 
 */
package diagConcreta.diagram.providers.assistants;

/**
 * @generated
 */
public class DiagConcretaModelingAssistantProviderOfMBSAtributoEditPart
		extends diagConcreta.diagram.providers.DiagConcretaModelingAssistantProvider {

}
