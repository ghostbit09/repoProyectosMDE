/*
 * 
 */
package concreta.diagram.edit.helpers;

/**
 * @generated
 */
public class MBSClaseEditHelper extends ConcretaBaseEditHelper {
}
