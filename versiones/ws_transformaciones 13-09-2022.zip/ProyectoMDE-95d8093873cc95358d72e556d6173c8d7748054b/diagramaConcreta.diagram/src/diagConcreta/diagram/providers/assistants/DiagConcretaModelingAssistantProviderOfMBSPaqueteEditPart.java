/*
 * 
 */
package diagConcreta.diagram.providers.assistants;

/**
 * @generated
 */
public class DiagConcretaModelingAssistantProviderOfMBSPaqueteEditPart
		extends diagConcreta.diagram.providers.DiagConcretaModelingAssistantProvider {

}
