/*
 * 
 */
package diagConcreta.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class DiagConcretaIconProvider extends DefaultElementTypeIconProvider implements IIconProvider {

	/**
	* @generated
	*/
	public DiagConcretaIconProvider() {
		super(diagConcreta.diagram.providers.DiagConcretaElementTypes.TYPED_INSTANCE);
	}

}
