/*
 * 
 */
package diagConcreta.diagram.edit.helpers;

/**
 * @generated
 */
public class MBSClaseEditHelper extends diagConcreta.diagram.edit.helpers.DiagConcretaBaseEditHelper {
}
