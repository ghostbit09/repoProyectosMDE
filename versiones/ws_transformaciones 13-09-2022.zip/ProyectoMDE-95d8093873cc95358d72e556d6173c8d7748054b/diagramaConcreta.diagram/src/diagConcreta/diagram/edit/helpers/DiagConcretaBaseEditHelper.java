/*
 * 
 */
package diagConcreta.diagram.edit.helpers;

import org.eclipse.gmf.tooling.runtime.edit.helpers.GeneratedEditHelperBase;

/**
 * @generated
 */
public class DiagConcretaBaseEditHelper extends GeneratedEditHelperBase {

}
