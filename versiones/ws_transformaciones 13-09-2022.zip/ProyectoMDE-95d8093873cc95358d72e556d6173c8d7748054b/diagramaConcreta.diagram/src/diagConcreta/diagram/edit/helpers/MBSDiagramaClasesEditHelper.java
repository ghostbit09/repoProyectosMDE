/*
 * 
 */
package diagConcreta.diagram.edit.helpers;

/**
 * @generated
 */
public class MBSDiagramaClasesEditHelper extends diagConcreta.diagram.edit.helpers.DiagConcretaBaseEditHelper {
}
