/*
 * 
 */
package diagConcreta.diagram.edit.helpers;

/**
 * @generated
 */
public class MBSAtributoEditHelper extends diagConcreta.diagram.edit.helpers.DiagConcretaBaseEditHelper {
}
