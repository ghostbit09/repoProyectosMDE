/*
 * 
 */
package concreta.diagram.edit.helpers;

/**
 * @generated
 */
public class MBSHerenciaEditHelper extends ConcretaBaseEditHelper {
}
