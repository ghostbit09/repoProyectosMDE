/*
 * 
 */
package concreta.diagram.edit.helpers;

/**
 * @generated
 */
public class MBSRelacionEditHelper extends ConcretaBaseEditHelper {
}
