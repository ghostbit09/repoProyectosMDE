/*
 * 
 */
package concreta.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.ConnectionsPreferencePage;

import concreta.diagram.part.ConcretaDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramConnectionsPreferencePage extends ConnectionsPreferencePage {

	/**
	* @generated
	*/
	public DiagramConnectionsPreferencePage() {
		setPreferenceStore(ConcretaDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
